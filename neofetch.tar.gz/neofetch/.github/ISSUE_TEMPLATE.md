## Descrição

Se você está sugerindo um novo recurso, apenas uma descrição
será suficiente.

- [ ] Essa falha ainda ocorre na ramificação master ? (**Obrigatório se a falha**)


#### Versão Neofetch

## Captura de tela

## Arquivo de configuração.

## Descrição detalhada.

1. Faça o procedimento de `neofetch -vv 2> neofetchlog`
2. Carregue o conteúdo de `neofetchlog` para localhost.



